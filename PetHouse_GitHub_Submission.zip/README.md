# Pet House — Web Technology College Submission

The ZIP contains the exact requested layout: `Admin/` (5 HTML pages), `Client/` (5 HTML pages), four numbered PDF files, and `5. github.txt`.

The fully working source is in `PetHouse_Source/`. Run `npm start` inside that directory with Node.js 18+ installed, then visit http://localhost:3000/. For the numbered pages, use http://localhost:3000/Client/1%20-%20Home%20Page.html or http://localhost:3000/Admin/1%20-%20Profile.html.

The 10 numbered HTML pages are working navigational views of the real application, not 10 separately implemented systems. Live data, account creation and admin management require the Node server.

The supplied university PDF files are assignment templates, not completed reports. The wireframe is specific to Pet House.
